import openai
import dotenv
import logging

env = dotenv.dotenv_values(".env")
logger = logging.getLogger(__name__)

class LLMService:
    def __init__(self, sys_prompt=None):
        try:
            
            self.client = openai.OpenAI(
                api_key=env["YA_API_KEY"],
                base_url="https://llm.api.cloud.yandex.net/v1",
            )
            
            self.sys_prompt = sys_prompt
            
            self.model = "gpt://b1gpvne2idtomp26c6ib/yandexgpt-lite"

        except Exception as e:
            return f"Произошла ошибка: {str(e)}"

    def chat(self, message, history):
        
        messages=[{"role": "system", "content": self.sys_prompt}] + history[-2:] + [{"role": "user", "content": message}]
        logger.info(f"Message: {messages}")
        try:
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=1.0,
                max_tokens=100,
            )
            logger.info(f"Response: {response}")
        
            return response.choices[0].message.content

        except Exception as e:
            return f"Произошла ошибка: {str(e)}"
